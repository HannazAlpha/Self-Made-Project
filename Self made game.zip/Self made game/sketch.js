var player;
var lastkey, bgimg;
var bunnyGroup;
var slimeGroup;
var energy = 360;
var score = 0;
var gameState="play";

function preload() {
  playerAnimations = {
    downIdle: loadAnimation('assets/player/_down idle/tile000.png','assets/player/_down idle/tile004.png'),
    downWalk: loadAnimation('assets/player/_down walk/tile000.png','assets/player/_down walk/tile005.png'),
    downAttack: loadAnimation('assets/player/_down attack/tile000.png','assets/player/_down attack/tile002.png'),
    upIdle: loadAnimation('assets/player/_up idle/tile000.png','assets/player/_up idle/tile004.png'),
    upWalk: loadAnimation('assets/player/_up walk/tile000.png','assets/player/_up walk/tile005.png'),
    upAttack: loadAnimation('assets/player/_up attack/tile000.png','assets/player/_up attack/tile002.png'),
    leftIdle: loadAnimation('assets/player/_left idle/tile000.png','assets/player/_left idle/tile004.png'),
    leftWalk: loadAnimation('assets/player/_left walk/tile000.png','assets/player/_left walk/tile005.png'),
    leftAttack: loadAnimation('assets/player/_left attack/tile000.png','assets/player/_left attack/tile002.png'),
    rightIdle: loadAnimation('assets/player/_right idle/tile000.png','assets/player/_right idle/tile004.png'),
    rightWalk: loadAnimation('assets/player/_right walk/tile000.png','assets/player/_right walk/tile005.png'),
    rightAttack: loadAnimation('assets/player/_right attack/tile000.png','assets/player/_right attack/tile002.png')
  };

  bunnyAnimations = {
    downIdle: loadAnimation('assets/bunny/_down idle/tile000.png','assets/bunny/_down idle/tile003.png'),
    downWalk: loadAnimation('assets/bunny/_down walk/tile000.png','assets/bunny/_down walk/tile003.png'),
    upIdle: loadAnimation('assets/bunny/_up idle/tile000.png','assets/bunny/_up idle/tile003.png'),
    upWalk: loadAnimation('assets/bunny/_up walk/tile000.png','assets/bunny/_up walk/tile003.png'),
    leftIdle: loadAnimation('assets/bunny/_left idle/tile000.png','assets/bunny/_left idle/tile003.png'),
    leftWalk: loadAnimation('assets/bunny/_left walk/tile000.png','assets/bunny/_left walk/tile003.png'),
    rightIdle: loadAnimation('assets/bunny/_right idle/tile000.png','assets/bunny/_right idle/tile003.png'),
    rightWalk: loadAnimation('assets/bunny/_right walk/tile000.png','assets/bunny/_right walk/tile003.png')
  };

  slimeAnimations = {
    downWalk: loadAnimation('assets/slime/_down walk/tile000.png','assets/slime/_down walk/tile005.png'),
    upWalk: loadAnimation('assets/slime/_up walk/tile000.png','assets/slime/_up walk/tile005.png'),
    leftWalk: loadAnimation('assets/slime/_left walk/tile000.png','assets/slime/_left walk/tile005.png'),
    rightWalk: loadAnimation('assets/slime/_right walk/tile000.png','assets/slime/_right walk/tile005.png')
  };

  bgimg = loadImage('assets/bg.jpg')
}

function setup(){
  createCanvas(windowWidth,windowHeight);

  player = createSprite(displayWidth*50/100, displayHeight*50/130, 1000, 1000);
  player.scale = 2.5;
  player.depth = 2;
  player.setCollider('rectangle',0,0,15,25)

  for (var animation in playerAnimations) {
    player.addAnimation(animation, playerAnimations[animation]);
  }

  bunnyGroup = new Group();
  slimeGroup = new Group();
}

function draw (){
  background(bgimg);

  fill('black');
  rect(50,20,360,20);
  fill('red');
  rect(50,20,energy,20);
  stroke(10)
  textSize(25)
  fill('black')
  text('Score : '+ score,displayWidth-200,40);

  playerMovement();
  playerAttack();
  spawnBunnies();
  spawnSlime();

  for (var i=0 ; i<bunnyGroup.length ; i++){ 
    if (bunnyGroup[i].isTouching(player)){
      score += 1
      bunnyGroup[i].destroy()
    }
  }

  for (var i=0 ; i<slimeGroup.length ; i++){ 
    if (slimeGroup[i].isTouching(player)){
      if (energy > 0){
        energy -= 20
        slimeGroup[i].destroy()
      }
    }
  }

  drawSprites();

  if (energy === 0){
    gameState="lost"
  }

  if (score === 50){
    gameState="won"
  }
  
  if (gameState==="won"){
    textSize(100)
    fill('green')
    text("Good Job",displayHeight/2,displayWidth/2-300)
    slimeGroup.destroyEach()
    bunnyGroup.destroyEach()
    player.destroy()
  }

  if (gameState==="lost"){
    textSize(100)
    fill('red')
    text("Game Over",displayHeight/2,displayWidth/2-300)
    slimeGroup.destroyEach()
    bunnyGroup.destroyEach()
    player.destroy()
  }
}

function playerMovement() {
  if (keyDown("S")) {
    player.y += 2.5;
    player.changeAnimation('downWalk');
    lastkey = 'down';
  } else if (lastkey == 'down'){
    player.changeAnimation('downIdle');
  }

  if (keyDown("W")) {
    player.y -= 2.5;
    player.changeAnimation('upWalk');
    lastkey = 'up';
  } else if (lastkey == 'up'){
    player.changeAnimation('upIdle');
  }

  if (keyDown("A")) {
    player.x -= 2.5;
    player.changeAnimation('leftWalk');
    lastkey = 'left';
  } else if (lastkey == 'left'){
    player.changeAnimation('leftIdle');
  }

  if (keyDown("D")) {
    player.x += 2.5;
    player.changeAnimation('rightWalk');
    lastkey = 'right';
  } else if (lastkey == 'right'){
    player.changeAnimation('rightIdle');
  }
}

function playerAttack() {
  if (keyDown("space")) {
    if (lastkey == 'down') {
      player.changeAnimation('downAttack');
    } else if (lastkey == 'up') {
      player.changeAnimation('upAttack');
    } else if (lastkey == 'left') {
      player.changeAnimation('leftAttack');
    } else if (lastkey == 'right') {
      player.changeAnimation('rightAttack');
    }
  }
}

function spawnBunnies() {
  if (frameCount % 100 === 0) {
    var bunny = createSprite(-10, random(10,windowHeight-10), 1000, 1000);
    bunny.scale = 3;
    bunny.depth = 1;
    bunny.setCollider('rectangle',0,0,10,15)

    for (var animation in bunnyAnimations) {
      bunny.addAnimation(animation, bunnyAnimations[animation]);
    }

    bunny.changeAnimation('rightWalk');
    bunny.velocityX = 2;
    bunnyGroup.add(bunny);
    bunny.lifetime = 800;

    if (bunny.y > player.y) {
      bunny.depth = 3;
    }
  }
}

function spawnSlime() {
  if (frameCount % 50 === 0) {
    var slime = createSprite(random(10,windowWidth-10), -10, 1000, 1000);
    slime.scale = 2.5;
    slime.depth = 1;
    slime.setCollider('rectangle',0,0,12,17)

    for (var animation in slimeAnimations) {
      slime.addAnimation(animation, slimeAnimations[animation]);
    }

    slime.changeAnimation('downWalk');
    slime.velocityY = 3;
    slimeGroup.add(slime);
    slime.lifetime = 500;
  }
}